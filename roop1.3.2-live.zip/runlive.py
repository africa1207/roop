#!/usr/bin/env python3

from roop import corelive

if __name__ == '__main__':
    corelive.run()
